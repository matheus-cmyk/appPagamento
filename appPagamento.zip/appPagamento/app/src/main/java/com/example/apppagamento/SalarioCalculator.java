package com.example.apppagamento;

public class SalarioCalculator {
    public static double calcularINSS(double salarioBruto) {
        if (salarioBruto <= 1212.00) {
            return salarioBruto * 0.075;
        } else if (salarioBruto <= 2427.35) {
            return salarioBruto * 0.09;
        } else if (salarioBruto <= 3641.03) {
            return salarioBruto * 0.12;
        } else if (salarioBruto <= 7087.22) {
            return salarioBruto * 0.14;
        } else {
            return 7087.22 * 0.14; // Teto máximo
        }
    }

    public static double calcularIR(double salarioBruto) {
        if (salarioBruto <= 1903.98) {
            return 0.0;
        } else if (salarioBruto <= 2826.65) {
            return (salarioBruto - 1903.98) * 0.075;
        } else if (salarioBruto <= 3751.05) {
            return (salarioBruto - 2826.65) * 0.15 + calcularIR(2826.65);
        } else if (salarioBruto <= 4664.68) {
            return (salarioBruto - 3751.05) * 0.225 + calcularIR(3751.05);
        } else {
            return (salarioBruto - 4664.68) * 0.275 + calcularIR(4664.68);
        }
    }

    public static double calcularSalarioFamilia(double salarioBruto, int numeroFilhos) {
        if (salarioBruto <= 1212.00) {
            return numeroFilhos * 56.47;
        }
        return 0.0;
    }

    public static double calcularSalarioLiquido(double salarioBruto, double descontoINSS, double descontoIR, double salarioFamilia) {
        return salarioBruto - descontoINSS - descontoIR + salarioFamilia;
    }
}