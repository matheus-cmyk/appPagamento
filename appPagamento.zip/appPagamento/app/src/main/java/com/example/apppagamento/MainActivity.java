package com.example.apppagamento;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private EditText edtNome, edtSalarioBruto, edtNumeroFilhos;
    private RadioGroup rgSexo;
    private TextView tvInss, tvIr, tvSalarioLiquido;
    private Button btnCalcular;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edtNome = findViewById(R.id.edtNome);
        edtSalarioBruto = findViewById(R.id.edtSalarioBruto);
        edtNumeroFilhos = findViewById(R.id.edtNumeroFilhos);
        rgSexo = findViewById(R.id.rgSexo);
        tvInss = findViewById(R.id.tvInss);
        tvIr = findViewById(R.id.tvIr);
        tvSalarioLiquido = findViewById(R.id.tvSalarioLiquido);
        btnCalcular = findViewById(R.id.btnCalcular);

        btnCalcular.setOnClickListener(v -> {
            try {
                String nome = edtNome.getText().toString();
                double salarioBruto = Double.parseDouble(edtSalarioBruto.getText().toString());
                int numeroFilhos = Integer.parseInt(edtNumeroFilhos.getText().toString());
                int selectedSexoId = rgSexo.getCheckedRadioButtonId();

                if (nome.isEmpty() || selectedSexoId == -1) {
                    Toast.makeText(this, "Preencha todos os campos corretamente.", Toast.LENGTH_SHORT).show();
                    return;
                }

                String tratamento = selectedSexoId == R.id.rbMasculino ? "Sr." : "Sra.";
                double descontoINSS = SalarioCalculator.calcularINSS(salarioBruto);
                double descontoIR = SalarioCalculator.calcularIR(salarioBruto);
                double salarioFamilia = SalarioCalculator.calcularSalarioFamilia(salarioBruto, numeroFilhos);
                double salarioLiquido = SalarioCalculator.calcularSalarioLiquido(salarioBruto, descontoINSS, descontoIR, salarioFamilia);

                tvInss.setText(String.format("INSS R$: %.2f", descontoINSS));
                tvIr.setText(String.format("IR R$: %.2f", descontoIR));
                tvSalarioLiquido.setText(String.format("%s %s, seu salário líquido é R$: %.2f", tratamento, nome, salarioLiquido));
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Insira valores numéricos válidos.", Toast.LENGTH_SHORT).show();
            }
        });
    }
}